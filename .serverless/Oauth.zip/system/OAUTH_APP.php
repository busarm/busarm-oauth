<?php
defined('OAUTH_BASE_PATH') OR exit('No direct script access allowed');
require_once "OAUTH_APP_CONFIGS.php";

/**
 * Created by PhpStorm.
 * User: Samuel
 * Date: 10/14/2018
 * Time: 12:34 AM
 *
 * Manage Content Delivery for Wecari
 *
 * @copyright wecari.com
 */

class OAUTH_APP {

    private $controllerDir = OAUTH_APP_CONFIGS::OAUTH_CONTROLLER_PATH;
    private $viewDir = OAUTH_APP_CONFIGS::OAUTH_VIEW_PATH;
    private $modelDir = OAUTH_APP_CONFIGS::OAUTH_MODEL_PATH;
    private $libraryDir = OAUTH_APP_CONFIGS::OAUTH_LIBRARY_PATH;

    private static $instance;

    public function __construct(){
        self::$instance = $this;
    }

    /**
     * Get App Instance
     *
     * @return OAUTH_APP
     */
    public static function getInstance(){
        return self::$instance;
    }

    /**
     * Get PATH for CDN
     *
     * @param string $path
     * @return void
     */
    public static function get_cdn_path($path = ''){
        if (ENVIRONMENT == ENV_PROD)
            return "https://cdn.wecari.com/".$path;
        else  if (ENVIRONMENT == ENV_TEST)
            return "https://cdn.staging.wecari.com/".$path;
        else
            return OAUTH_BASE_SERVER . "/wecari.com/cdn/".$path;
    }

    /**
     * Initialize app
     */
    public function initialize ()
    {
        
        // Check for CORS access request
        if (OAUTH_APP_CONFIGS::CHECK_CORS == TRUE) {
            $this->check_cors();
        }
        else {
            // If the request HTTP method is 'OPTIONS', kill the response and send it to the client
            if (strtolower(getServer("REQUEST_METHOD")) === 'options') {
                $this->showMessage(200, true, "Preflight Ok", ENVIRONMENT);
            }
        }

        /*Initiate rerouting*/
        $request_path = getServer('PATH_INFO');
        if (empty($request_path)) {
            $request_path = getServer('ORIG_PATH_INFO');
        }
        if (empty($request_path)) {
            $request_path = getServer('REQUEST_URI');
        }
        if (!empty($request_path)) {
            if(preg_match('/\/ping(\/)?$/',$request_path)){
                $this->showMessage(200, true, "System Online", ENVIRONMENT);
            }
            else { 
                $routes = explode('/', explode('?',$request_path)[0]);
                $this->reroute($routes);
            }
        } else {
            $this->showMessage(404, false, "Invalid Request", "Invalid Request Path");
        } 
    }

    /**Re-Routing
     * @param $routes
     */
    private function reroute ($routes)
    {
        $actualPath = "";
        $controller = "";
        $function = "";
        $params = null;
        $param_key = null;
        $param_count = 0;

        foreach ($routes as $key => $route) {
            if (!empty(trim($route, "\n\r'\"\\/&%!@#$*)(|<>{}"))) {
                if ($key == 0) { //Route at section 0 = Controller
                    $controller = basename(trim($this->controllerDir . $route));
                    $actualPath .= $controller;
                    $actualPath .= ".php";
                } else if ($key == 1){ //Route at section 1 = Function
                    $function = $route;
                } else { //Every other section. = Url params
                    $param_count++;
                    if ($param_count % 2 == 0) {
                        $params[$param_key] = $route;
                    } else {
                        $param_key = $route;
                    }
                }
                if ($key == count($routes) - 1){  //Last
                    if (isset($params)) {
                        $_GET = $params;
                    }
                    if ($realPath = $this->fileExists($this->controllerDir . $actualPath, false)) {

                        try {

                            /*
                            * Let's Go...
                            */
                            require_once OAUTH_BASE_PATH . 'Server.php';
                            require_once $realPath;

                            if (class_exists(ucfirst($controller))) {

                                /*Load Class*/
                                /*Create instance of controller*/
                                $token = new $controller();

                                if (method_exists($token, $function)
                                    && is_callable(array($token, $function))) {
                                    call_user_func(
                                        array($token, $function)
                                    );
                                } else {
                                    $this-> showMessage(404, false, "Unknown Method", "Unknown Method - " . $function);
                                }
                            } else {
                                $this->showMessage(404, false, "Invalid Request", "Invalid request path - " . $controller);
                            }
                        } catch (Exception $e) {
                            $this->showMessage(500, false, "Invalid Request", $e->getMessage());
                        }
                    } else {
                        $this->showMessage(404, false, "Invalid Request", "Request path not found - " . $controller);
                    }
                    break; //unnecessary but just in-case...  can't be too sure ;)
                }
            } else {
                unset($routes[$key]);
                $routes = array_values($routes);
                $this->reroute($routes);
                break;
            }
        }

    }


    /**Case Insensitive search
     * @param $fileName string
     * @param $caseSensitive bool
     * @return mixed
     */
    private function fileExists($fileName, $caseSensitive = true)
    {

        if (file_exists($fileName)) {
            return $fileName;
        }
        if ($caseSensitive) return false;

        // Handle case insensitive requests
        $directoryName = dirname($fileName);
        $fileArray = glob($directoryName . '/*', GLOB_NOSORT);
        $fileNameLowerCase = strtolower($fileName);
        foreach ($fileArray as $file) {
            if (strtolower($file) == $fileNameLowerCase) {
                return $file;
            }
        }
        return false;
    }


    /**
	 * Show Message
     * @param string $code Code
     * @param bool $status Status
     * @param string $title itle
     * @param string $msg Message
     */
    public function showMessage($code, $status, $title, $msg)
    {
        header(PROTOCOL_HEADER . ' ' . $code . ' ' . $title, TRUE, $code);
        header("Content-type: application/json");
        header('Access-Control-Allow-Origin: *', true);
        header('Access-Control-Allow-Methods: *', true); 
        if($status){
            echo json_encode(['status'=>true, 'msg' => $title, 'env' => ENVIRONMENT]);
        }
        else {
            echo json_encode(['status'=>false, 'error' => $title, 'error_description' => $msg, 'env' => ENVIRONMENT]);
        }
        exit;
    }


    /**Get File From path
     * @param $filePath
     * @return bool|string
     */
    public function get_file($filePath)
    {
        $data = false;
        if (isset($filePath)) {
            //$dl_file = preg_replace("([^\w\s\d\-_~,;:\[\]\(\).]|[\.]{2,})", '', $filePath); // simple file name validation
            $dl_file = filter_var($filePath, FILTER_SANITIZE_URL); // Remove (more) invalid characters
            $fullPath = $dl_file;

            if (file_exists($fullPath)) {

                try {
                    $fd = @fopen($fullPath, "r");
                } finally {
                    if ($fd) {
                        $file = @fread($fd, filesize($fullPath));
                        $data = $file;
                        fclose($fd);
                    }
                }
            }
        }

        return $data;
    }


    /**Load View
     * @param $path
     * @param array $vars
     * @param bool $return
     * @return string
     * @throws Exception
     */
    public function loadView($path, $vars = array(), $return = false)
    {
        if ($filePath = $this->fileExists($this->viewDir . $path . ".php")) {
            ob_start();
            if (!empty($vars))
                extract($vars);
            include $filePath;
            $content = ob_get_contents();
            ob_end_clean();
            ob_flush();

            if ($return) {
                return $content;
            } else {
                echo $content;
                exit;
            }
        } else {
            if ($return) {
                return null;
            } else {
                throw new Exception("File does not Exist");
            }
        }
    }

    /**Load Library
     * @param $path
     * @param array $vars
     * @throws Exception
     */
    public function loadLibrary($path, $vars = array())
    {
        if ($filePath = $this->fileExists($this->libraryDir . $path . ".php")) {
            if (!empty($vars))
                extract($vars);
            require_once $filePath;
        } else {
            throw new Exception("File does not Exist");
        }
    }


    /**Load Model
     * @param $path
     * @param array $vars
     * @throws Exception
     */
    public function loadModel($path, $vars = array())
    {
        if ($filePath = $this->fileExists($this->modelDir . $path . ".php")) {
            if (!empty($vars))
                extract($vars);
            require_once $filePath;
        } else {
            throw new Exception("File does not Exist");
        }
    }

    /**Generate CSRF TOKEN
     * @return string
     */
    public function generate_csrf_token()
    {
        $dateObj = new DateTime("now", new DateTimeZone("GMT"));
        $unique = md5(uniqid(IPADDRESS));
        $this->set_cookie("csrf_key",$unique);
        $csrf_token = md5($unique. IPADDRESS. OAUTH_BASE_URL . $dateObj->format('Y-m-d H'));
        return $csrf_token;
    }


    /**Get CSRF TOKEN
     * @return string
     */
    public function get_csrf_token()
    {
        if(!empty($unique = $this->get_cookie("csrf_key"))){
            $dateObj = new DateTime("now", new DateTimeZone("GMT"));
            $csrf_token = md5($unique. IPADDRESS. OAUTH_BASE_URL . $dateObj->format('Y-m-d H'));
            $this->delete_cookie("csrf_key");
            return $csrf_token;
        }
        return null;
    }

    /**CSRF Validation
     * @param string $csrf_token
     * @return array|boolean
     */
    public function validate_csrf_token($csrf_token)
    {
        if ($csrf_token) {
            return $csrf_token == $this->get_csrf_token();
        }
        return false;
    }

    /**
     * Get cookie
    * @param String $name
    * @return void
    */
    public function get_cookie($name){
        return !empty($_COOKIE["oauth_".$name])? @$_COOKIE["oauth_".$name] : null;
    }

    /**
     * Set cookie
     *
     * @param [type] $name
     * @param [type] $value
     * @param integer $duration
     * @return bool
     */
    public function set_cookie($name, $value, $duration = 3600){
        return setcookie("oauth_".$name, $value, time() + $duration, "/");
    }

    /**
     * Delete cookie
     * @param String $name
     * @return bool
     */
    public function delete_cookie($name){
        return setcookie("oauth_".$name, "", time() - 3600);
    }



    /**
     * Check to see if the API key has access to the controller and methods
     *
     * @access protected
     * @return bool TRUE the API key has access; otherwise, FALSE
     */
    protected function _check_access()
    {
        // If we don't want to check access, just return TRUE
        if ($this->config->item('rest_enable_access') === FALSE) {
            return TRUE;
        }

        //check if the key has all_access
        $accessRow = $this->rest->db
            ->where('key', $this->rest->key)
            ->get($this->config->item('rest_access_table'))->row_array();

        if (!empty($accessRow) && !empty($accessRow['all_access'])) {
            return TRUE;
        }

        // Fetch controller based on path and controller name
        $controller = implode(
            '/', [
            $this->router->directory,
            $this->router->class
        ]);

        // Remove any double slashes for safety
        $controller = str_replace('//', '/', $controller);

        // Query the access table and get the number of results
        return $this->rest->db
                ->where('key', $this->rest->key)
                ->where('controller', $controller)
                ->get($this->config->item('rest_access_table'))
                ->num_rows() > 0;
    }

    /**
     * Checks allowed domains, and adds appropriate headers for HTTP access control (CORS)
     * @credits Codeigniter
     * 
     * @access protected
     * @return void
     */
    protected function check_cors()
    {
        $allowed_cors_headers = OAUTH_APP_CONFIGS::ALLOWED_CORS_HEADERS;
        $exposed_cors_headers = OAUTH_APP_CONFIGS::EXPOSED_CORS_HEADERS;
        $allowed_cors_methods = OAUTH_APP_CONFIGS::ALLOWED_CORS_METHODS;

        // Convert the config items into strings
        $allowed_headers = implode(', ', is_array($allowed_cors_headers) ? $allowed_cors_headers : []);
        $exposed_cors_headers = implode(', ', is_array($exposed_cors_headers) ? $exposed_cors_headers : []);
        $allowed_methods = implode(', ', is_array($allowed_cors_methods) ? $allowed_cors_methods : []);

        // If we want to allow any domain to access the API
        if (OAUTH_APP_CONFIGS::ALLOWED_ANY_CORS_DOMAIN == TRUE) {
            header(PROTOCOL_HEADER . " 200 OK", TRUE, 200);
            header('Access-Control-Allow-Origin: *', true);
            header('Access-Control-Allow-Methods: ' . $allowed_methods, true);
            header('Access-Control-Allow-Headers: ' . $allowed_headers, true);
            header('Access-Control-Expose-Headers: ' . $exposed_cors_headers, true);
        } else {

            // We're going to allow only certain domains access
            // Store the HTTP Origin header
            $origin = getServer('HTTP_ORIGIN');
            if ($origin === NULL) {
                $origin = getServer('HTTP_REFERER');
                if ($origin === NULL) {
                    $origin = '';
                }
            }

            $allowed_origins = OAUTH_APP_CONFIGS::ALLOWED_CORS_ORIGINS;

            // If the origin domain is in the allowed_cors_origins list, then add the Access Control headers
            if (is_array($allowed_origins) && in_array(trim($origin, "/"), $allowed_origins)) {
                header(PROTOCOL_HEADER . " 200 OK", true, 200);
                header('Access-Control-Allow-Origin: ' . $origin, true);
                header('Access-Control-Allow-Methods: ' . $allowed_methods, true);
                header('Access-Control-Allow-Headers: ' . $allowed_headers, true);
                header('Access-Control-Expose-Headers: ' . $exposed_cors_headers, true);
            }
        }

        // If the request HTTP method is 'OPTIONS', kill the response and send it to the client
        if (strtolower(getServer("REQUEST_METHOD")) === 'options') {
            die();
        }
    }
}